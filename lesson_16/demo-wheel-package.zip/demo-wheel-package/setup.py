import setuptools


with open('README.md', 'r') as file:
    long_description = file.read()

setuptools.setup(
    name='demo_wheel',
    version='0.0.3',
    author='Yurii Bondarenko',
    description='Demo Wheel',
    long_description=long_description,
    long_description_content_type='text/markdown',
    packages=setuptools.find_packages(),
    python_requires='>=3.10',
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: Linux :: Ubuntu"
    ]
)
